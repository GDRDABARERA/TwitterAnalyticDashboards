for(var i=0;i<1000;i++){

    var j=i;


}

postMessage(j);


/*
--------------------

var sd = function(){
 var api=this;

 api.getGrpagh= functrion(v,hjk,){

 }

}

*/